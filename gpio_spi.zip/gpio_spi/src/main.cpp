#include <stdio.h>
#include <stdlib.h>
#include <string>
// #include <linux/delay.h>
#include <linux/gpio.h>
#include <stdio.h>
#include <gpiod.h>
#include <iostream>
#include <unistd.h>
#include <ctime>
#include <cstdlib>
#include <time.h>


// #include <linux/of_gpio.h>

// gpiochip0: GPIOs 0-31  √      
// gpiochip1: GPIOs 32-63  bad
// gpiochip2: GPIOs 64-95, bad
// gpiochip3: GPIOs 96-127, bad

// 视频输入
// #define _SPI_CLK  65   //   gpio_spi_sclk   接口的关键时序组件。
// #define _SPI_MISO 68    //  gpio_spi_miso
// #define _SPI_MOSI 67   //   gpio_spi_mosi
// #define _SPI_CS   16    //  gpio_spi_cs  // 片选  低有效的信号 第0路   2971
// #define _SPI_CS   17    //  gpio_spi_cs  // 片选  低有效的信号 第1路


// sdi output
#define _SPI_CLK  47  //   gpio_spi_sclk   接口的关键时序组件。
#define _SPI_MISO 52  //  gpio_spi_miso
#define _SPI_MOSI 51  //   gpio_spi_mosi
#define _SPI_CS   48  //  gpio_spi_cs  // 片选  低有效的信号


// read
#define T0 1       //   min 1.5ns
#define T1 2       //   T1: SCLK period. 
#define T5 50      //   min 150ns. 
#define T7 80      //   the delay that SCSb goes high after the last SCLK

// // write
#define T4 50      //   min 150ns. 


int gpio_direction_output(struct gpiod_line * line, int line_num, int value, const std::string& name) {
    // 配置引脚为输出
    int ret = gpiod_line_request_output(line, name.c_str(), 0);
    if (ret < 0) {
        perror("Request GPIO line as output");
        // gpiod_line_release(line);
        return -1;
    }

    gpiod_line_set_value(line, value);
    // gpiod_line_release(line);
    return 0;
}

int gpio_direction_input(struct gpiod_line * line, int line_num) {

    int ret;
    // 配置引脚为输入
    ret = gpiod_line_request_input(line, "_SPI_MISO");
    if (ret < 0) {
        perror("Request GPIO line as input");
        // gpiod_line_release(line);
        return -1;
    }

    gpiod_line_set_value(line, 0);

    // gpiod_line_release(line);
    return 0;
}



void openchip(struct gpiod_chip*& chip, int id)
{
    int real_id = int(id / 32);
    std::string read_chipaddr = "/dev/gpiochip" + std::to_string(real_id);

    chip = gpiod_chip_open(read_chipaddr.c_str());

    if (!chip) {
        perror("Open GPIO chip");
        return ;//-1;
    }
}


void openchips(struct gpiod_chip*& chip_clk, struct gpiod_chip *& chip_cs, struct gpiod_chip *& chip_miso, struct gpiod_chip *& chip_mosi)
{   
    //int ret;
    openchip(chip_clk, _SPI_CLK);
    openchip(chip_cs, _SPI_CS);
    openchip(chip_miso, _SPI_MISO);
    openchip(chip_mosi, _SPI_MOSI);
    printf("open all chips successful.\n");

    // return 0;
}


void openline(struct gpiod_chip* chip, struct gpiod_line *& line, int id)
{   

    // // 获取GPIO引脚
    line = gpiod_chip_get_line(chip, id % 32);  // 根据实际的引脚号更改
    if (!line) {
        perror("I get GPIO line");
        // gpiod_chip_close(chip);
        return;
    }
    printf("open line %d successful.\n", id);
    // return 0;
}




void spi_write_data(struct gpiod_line *& line_clk, struct gpiod_line *& line_cs, struct gpiod_line *& line_miso, struct gpiod_line *& line_mosi,
                    uint16_t address, uint16_t data)
{
    gpiod_line_set_value(line_clk, 0); // SCLK must be low when SCSb changes from high to low
    gpiod_line_set_value(line_cs, 0);
    usleep(T0);

    printf("spi write addr-----------------------\n");
    for (int i=15; i >= 0; i--)
    {
        gpiod_line_set_value(line_mosi, (address>>i) & 0x01);
        printf("lt9211c_spi addr MOSI W = %d, %d, %d \n", (address>>i)&0x01, gpiod_line_get_value(line_mosi), gpiod_line_get_value(line_miso));
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 1);
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 0);
    }

    usleep(T4);
    printf("spi write data-----------------------\n");

    for (int i=15; i >= 0; i--)
    {
        gpiod_line_set_value(line_mosi, (data>>i) & 0x01);
        printf("lt9211c_spi addr MOSI W = %d, %d, %d \n", (address>>i)&0x01, gpiod_line_get_value(line_mosi), gpiod_line_get_value(line_miso));
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 1);
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 0);
    }

    usleep(T7);
    gpiod_line_set_value(line_cs, 1);

}


void spi_read_data(struct gpiod_line *& line_clk, struct gpiod_line *& line_cs, struct gpiod_line *& line_miso, struct gpiod_line *& line_mosi,
                    uint16_t address, uint16_t& data)
{
    gpiod_line_set_value(line_clk, 0); // SCLK must be low when SCSb changes from high to low
    gpiod_line_set_value(line_cs, 0);
    usleep(T0);  // T0: min 1.5ns since SCSb low to the first SCLK rising edge

    printf("spi read addr-----------------------\n");
    for (int i=15; i >= 0; i--)
    {
        gpiod_line_set_value(line_mosi, (address>>i) & 0x01);
        // printf("lt9211c_spi addr MOSI W = %d, %d, %d \n", (address>>i)&0x01, gpiod_line_get_value(line_mosi), gpiod_line_get_value(line_miso));
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 1);
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 0);
    }

    usleep(T5);
    printf("spi read data-----------------------\n");

    for (int i=15; i >= 0; i--)
    {
        usleep(T1/2);

        gpiod_line_set_value(line_clk, 1);

        int value = gpiod_line_get_value(line_miso);
        printf("lt9211c_spi R addr, _SPI_MISO = %d, %d \n", (address>>i)&0x01, value);
        data = (data<<1) | (value & 0x01);
        usleep(T1/2);
        gpiod_line_set_value(line_clk, 0);
    }

    usleep(T7);
    gpiod_line_set_value(line_cs, 1);
}

// gpiochip0: GPIOs 0-31
// gpiochip1: GPIOs 32-63
// gpiochip2: GPIOs 64-95
// gpiochip3: GPIOs 96-127
int main(int argc, const char *argv[])
{	

	struct gpiod_chip *chip_clk;
    struct gpiod_chip *chip_cs;
    struct gpiod_chip *chip_miso;
    struct gpiod_chip *chip_mosi;

    struct gpiod_line *line_clk;
    struct gpiod_line *line_cs;
    struct gpiod_line *line_miso;
    struct gpiod_line *line_mosi;

    // int ret;
    openchips(chip_clk, chip_cs, chip_miso, chip_mosi);

    openline(chip_clk, line_clk, _SPI_CLK);
    openline(chip_cs, line_cs, _SPI_CS);
    openline(chip_miso, line_miso, _SPI_MISO);
    openline(chip_mosi, line_mosi, _SPI_MOSI);

    /* SPI端口初始化 */  
    gpio_direction_output(line_clk, _SPI_CLK,  0, "_SPI_CLK");  // 设置为输出
    gpio_direction_output(line_cs, _SPI_CS,   1,  "_SPI_CS");  // 片选  设置为输出
    gpio_direction_output(line_mosi, _SPI_MOSI, 0,  "_SPI_MOSI");   //设置为输出
    gpio_direction_input(line_miso, _SPI_MISO);


    uint16_t write_addr = 0x000; //0x0009; //2971A的
    uint16_t write_data = 0xFFFF;  

    uint16_t read_addr = 0x8015; //0x8009;  //1000 0000 0000 0001
    uint16_t read_data = 0; 


    // printf("lt9211c_spi write write_addr, data: %x, %x\n", write_addr, write_data);
    // spi_write_data(line_clk, line_cs, line_miso, line_mosi,
    //                 write_addr, write_data);
    spi_read_data(line_clk, line_cs, line_miso, line_mosi,
                    read_addr, read_data);

    printf("spi read addr=%x, value=%x. \n", read_addr, read_data);
    // struct gpiod_chip* chip = gpiod_chip_open("/dev/gpiochip2");
    // if (!chip) {
    //     perror("Open GPIO chip");
    //     return 1;
    // }

    printf("-----------------------------\n");

    // // // 获取GPIO引脚
    // struct gpiod_line* line = gpiod_chip_get_line(chip, _SPI_CLK-64);  // 根据实际的引脚号更改
    // if (!line) {
    //     perror("I get GPIO line");
    //     gpiod_chip_close(chip);
    //     return 1;
    // }

    // printf("okkk\n");

    // // 配置引脚为输出
    

    // gpiod_line_set_value(line_clk, 1);
    // // 等待一段时间
    // sleep(1);

    // // 释放引脚和设备资源
    gpiod_line_release(line_clk);
    gpiod_line_release(line_cs);
    gpiod_line_release(line_mosi);
    gpiod_line_release(line_miso);
    gpiod_chip_close(chip_clk);
    gpiod_chip_close(chip_cs);
    gpiod_chip_close(chip_mosi);
    gpiod_chip_close(chip_miso);

    printf("Done.\n");
	return 0;
}